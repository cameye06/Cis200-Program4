﻿// Program 4
// CIS 200-01
// Due: 4/18/2018
// By: Z8360
//
//file: descendingYear
//this file uses icomperer to recieve copyright years sorted and pur them in reverse order
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    class descendingYear : IComparer<LibraryItem> // uses icomparer generic
    {
        public int Compare(LibraryItem i1, LibraryItem i2) // accepts two libraryitem years
        {
            //they were always false
            // Ensure correct handling of null values (in .NET, null less than anything)
            //if (i1.CopyrightYear == null && i2.CopyrightYear == null) // Both null?
            //    return 0;                 // Equal

            //if (i1.CopyrightYear == null) // only t1 is null?
            //    return -1;  // null is less than everything

            //if (i2.CopyrightYear == null) // only t2 is null? Always 
              /*  return 1; */  // Any actual year is greater than null

            return (-1) * i1.CopyrightYear.CompareTo(i2.CopyrightYear); // Reverses natural order, so descending
        }
    }
}
